#ifndef ALGORITMOS_H_INCLUDED
#define ALGORITMOS_H_INCLUDED

#include "Problema.h"
#include "Solucion.h"

Solucion AlgoritmoGreedyAGM(Problema p);


#endif // ALGORITMOS_H_INCLUDED
